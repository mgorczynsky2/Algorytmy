using System.Xml.Linq;

namespace a2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
            private void button1_Click(object sender, EventArgs e)
        {
            Wezel3 w2=new Wezel3(4);
            Wezel3 w3=new Wezel3(6);
            Wezel3 w4=new Wezel3(8);
            Wezel3 w5=new Wezel3(1);
            Wezel3 w6=new Wezel3(7);
            Wezel3 w7=new Wezel3(2);


            DrzewoBinarne d1 = new DrzewoBinarne(5);
            d1.korzen.Parent = null;
            d1.korzen.Left = w2;
            d1.korzen.Right= w3;
            d1.korzen.wartosc = 5;
            w2.dodaj(w7, w6, d1.korzen);
            w3.dodaj(w5,w4, d1.korzen);
            w7.dodaj(null, null, w2);
            w6.dodaj(null, null, w2);
            w5.dodaj(null, null, w3);
            w4.dodaj(null, null, w3);
            //d1.BFS();
            d1.Add(11);
            //d1.BFS();
            //Wezel3 w10 = d1.korzen.znajdz(6);
            //MessageBox.Show(w10.napisz());
            MessageBox.Show(d1.korzen.findMin(d1.korzen).ToString());
            MessageBox.Show(d1.korzen.findMax(d1.korzen).ToString());

        }
    }
    public class DrzewoBinarne
    {
        public Wezel3 korzen;


       
        public DrzewoBinarne(int liczba)
        {
            this.korzen = new Wezel3(liczba);
        }
        //znajdz Wezel3 znajdz(int liczba);
        //Wezel3 znajdzMin(Wezel3 w); 
        //znajdz znajdzMax(Wezel3 w);
        //znajdz wezel3 nastepnik(wezel3 w) a) jezeli jest prawe dziecko to uzyj znajdzmin(w.prawedziecko),
        //                                   b)jezeli nie ma prawego dziecka idz do gory az wyjdziesz jako lewe dziecko rodzica, nastepnik to rodzic,
        //                                   c)jezeli nie ma prawego dziecka i idac do gory nie ma (2)to nie ma nastepnika
        //wezel3 poprzednik(wezel3 w);(odwrotnie)
        public void BFS()
        {
            if (this == null)
            {
                return;
            }
            MessageBox.Show("Drzewo binarne: ");
            Queue<Wezel3> queue = new Queue<Wezel3>();
            queue.Enqueue(this.korzen);

            while (queue.Count > 0)
            {
                Wezel3 current = queue.Dequeue();

                // Wy�wietlanie warto�ci w MessageBox
                MessageBox.Show(current.wartosc.ToString());

                if (current.Left != null)
                {
                    queue.Enqueue(current.Left);
                }

                if (current.Right != null)
                {
                    queue.Enqueue(current.Right);
                }
            }
        }
        public void Add(int number)
        {
            Wezel3 rodzic = this.ZnajdzRodzica(number);
            rodzic.Add(number);
        }
        public Wezel3 ZnajdzRodzica(int liczba)
        {
            var w = this.korzen;
            while (true)
            {
                if (liczba < w.wartosc)
                {
                    if (w.Left == null)
                        return w;

                    w = w.Left;
                }
                else
                {
                    if (w.Right == null)
                        return w;
                  
                    w = w.Right;
                }

            }
        }
    }


    public class Wezel3
    {

        public int wartosc;
        public Wezel3 Left, Right, Parent;

        public Wezel3()
        {
        }
        public void Add(int liczba)
        {
            var dziecko = new Wezel3(liczba);
            dziecko.Parent = this;
            if (liczba < this.wartosc)
            {
                this.Left = dziecko;
            }
            this.Right = dziecko;
        }
        public Wezel3 ZnajdzPoprzednik(Wezel3 w)
        {
            if (w == null)
                return null;

            // Je�li w�ze� ma lewe poddrzewo, to poprzednikiem b�dzie najwi�kszy w�ze� w tym poddrzewie
            if (w.Left != null)
                return ZnajdzNajwiekszy(w.Left);

            // Je�li w�ze� nie ma lewego poddrzewa, to nale�y przej�� do rodzica i szuka� dalej
            Wezel3 parent = w.Parent;

            while (parent != null && w == parent.Left)
            {
                w = parent;
                parent = parent.Parent;
            }

            return parent;
        }

        // Pomocnicza metoda do znajdowania najwi�kszego w�z�a w danym poddrzewie
        private Wezel3 ZnajdzNajwiekszy(Wezel3 w)
        {
            while (w.Right != null)
            {
                w = w.Right;
            }

            return w;
        }
        public Wezel3 ZnajdzNastepnik(Wezel3 w)
        {
            if (w == null)
                return null;

            // Je�li w�ze� ma prawe poddrzewo, to nast�pnikiem b�dzie najmniejszy w�ze� w tym poddrzewie
            if (w.Right != null)
                return ZnajdzNajmniejszy(w.Right);

            // Je�li w�ze� nie ma prawego poddrzewa, to nale�y przej�� do rodzica i szuka� dalej
            Wezel3 parent = w.Parent;

            while (parent != null && w == parent.Right)
            {
                w = parent;
                parent = parent.Parent;
            }

            return parent;
        }

        // Pomocnicza metoda do znajdowania najmniejszego w�z�a w danym poddrzewie
        private Wezel3 ZnajdzNajmniejszy(Wezel3 w)
        {
            while (w.Left != null)
            {
                w = w.Left;
            }
            return w;
        }
        public int findMax(Wezel3 node)
        {
            if (node == null)
            {
                return int.MinValue;
            }

            int max = node.wartosc;
            int lmax = findMax(node.Left);
            int pmax = findMax(node.Right);

            if (lmax > max)
            {
                max = lmax;
            }
            if (pmax > max)
            {
                max = pmax;
            }
            return max;
        }
        public int findMin(Wezel3 node)
        {
            if (node == null)
                return int.MaxValue;
            int min = node.wartosc;
            int lmin = findMin(node.Left);
            int pmin = findMin(node.Right);

            if (lmin < min)
                min = lmin;
            if (pmin < min)
                min = pmin;
            return min;
        }
        public string napisz()
        {
            return (this.wartosc.ToString());
        }
        public Wezel3 znajdz(int szukanaWartosc)
        {
            if (this == null || this.wartosc == szukanaWartosc)
            {
                return this;
            }

            // If the value is less than the current node's value, search in the left subtree
            if (szukanaWartosc < this.wartosc)
            {
                if (this.Left != null)
                {
                    return this.Left.znajdz(szukanaWartosc);
                }
            }
            else
            { // If the value is greater, search in the right subtree
                if (this.Right != null)
                {
                    return this.Right.znajdz(szukanaWartosc);
                }
            }

            return null; // Node with the given value not found
        }
        public Wezel3(int item)
        {
            wartosc = item;
        }
        public void dodaj(Wezel3 lewy, Wezel3 prawy, Wezel3 parent)
        {
            this.Left = lewy;
            this.Right = prawy;
            this.Parent = parent;
        }
    }
}