namespace a2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
            private void button1_Click(object sender, EventArgs e)
        {
            Wezel3 w1 = new Wezel3(5);
            Wezel3 w2=new Wezel3(3);
            Wezel3 w3=new Wezel3(1);
            Wezel3 w4=new Wezel3(2);
            Wezel3 w5=new Wezel3(6);
            Wezel3 w6=new Wezel3(4);
            Wezel3 w7=new Wezel3(10);
            

            w1.dodaj(w2, w5);
            w2.dodaj(w3, w4);
            w5.dodaj(w6, w7);
            w1.BFS();
            w1.InsertRec(w1, 11);
            w1.BFS();
            w1.InsertRec(w1, 0);
            w1.BFS();

        }
    }

    public class DrzewoBinarne
    {
        public Wezel3 korzen;

        public DrzewoBinarne(int liczba)
        {
            this.korzen = new Wezel3(liczba);
        }
        //znajdz Wezel3 znajdz(int liczba);
        //Wezel3 znajdzMin(Wezel3 w); 
        //znajdz znajdzMax(Wezel3 w);
        //znajdz wezel3 nastepnik(wezel3 w) a) jezeli jest prawe dziecko to uzyj znajdzmin(w.prawedziecko),
        //                                   b)jezeli nie ma prawego dziecka idz do gory az wyjdziesz jako lewe dziecko rodzica, nastepnik to rodzic,
        //                                   c)jezeli nie ma prawego dziecka i idac do gory nie ma (2)to nie ma nastepnika
        //wezel3 poprzednik(wezel3 w);(odwrotnie)

        public Wezel3 ZnajdzRodzica(int liczba)
        {
            var w = this.korzen;
            while (true)
            {
                if (liczba < w.wartosc)
                {
                    if (w.Left == null)
                        return w;

                    w = w.Left;
                }
                else
                {
                    if (w.Right == null)
                        return w;
                  
                    w = w.Right;
                }

            }
        }
    }

    public class Wezel3
    { 
        
        public int wartosc;
        public Wezel3 Left, Right, Parent;

        public void Add(int liczba)
        {
            var dziecko = new Wezel3(liczba);
            dziecko.Parent = this;
            if(liczba<this.wartosc)
            {
                this.Left = dziecko;
            }
            this.Right = dziecko;
        }
       

        public Wezel3(int item)
        {
            wartosc = item;
        }
        public void dodaj(Wezel3 lewy, Wezel3 prawy)
        {
            this.Left = lewy;
            this.Right = prawy;
        }

        public Wezel3 InsertRec(Wezel3 root, int wartosc)
        {
            if (root == null)
            {
                root = new Wezel3(wartosc);
                return root;
            }
            if (wartosc < root.wartosc)
            {
                root.Left = InsertRec(root.Left, wartosc);
            }
            else if (wartosc >= root.wartosc)
            {
                root.Right = InsertRec(root.Right, wartosc);
            }
            return root;
        }
        public void BFS()
        {
            if (this == null)
            {
                return;
            }

            Queue<Wezel3> queue = new Queue<Wezel3>();
            queue.Enqueue(this);

            while (queue.Count > 0)
            {
                Wezel3 current = queue.Dequeue();

                // Wy�wietlanie warto�ci w MessageBox
                MessageBox.Show(current.wartosc.ToString());

                if (current.Left != null)
                {
                    queue.Enqueue(current.Left);
                }

                if (current.Right != null)
                {
                    queue.Enqueue(current.Right);
                }
            }
        }
    }
}