using static WinFormsApp1.Form1;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        List<Wezel2> odwiedzone = new List<Wezel2>();
        void A(Wezel2 w)
        {
            MessageBox.Show(w.wartosc.ToString());
            foreach (var sasiad in w.sasiedzi)
            {
                if (!odwiedzone.Contains(sasiad))
                    odwiedzone.Add(sasiad);
                    A(sasiad);
            }
        }
        public class Wezel2
        {
            public int wartosc;
            public List<Wezel2> sasiedzi = new List<Wezel2>();

            public Wezel2(int liczba)
            {
                this.wartosc = liczba;
            }
            public void dodaj(Wezel2 sasiad)
            {
                if (this == sasiad)
                    return;
                if (!this.sasiedzi.Contains(sasiad))
                {
                    this.sasiedzi.Add(sasiad);
                }
                if(!sasiad.sasiedzi.Contains(this))
                {
                    sasiad.sasiedzi.Add(this);
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Wezel2 w1 = new Wezel2(1);
            Wezel2 w2 = new Wezel2(2);
            Wezel2 w3 = new Wezel2(3);
            Wezel2 w4 = new Wezel2(4);
            Wezel2 w5 = new Wezel2(5);
            Wezel2 w6 = new Wezel2(6);
            Wezel2 w7 = new Wezel2(7);

            w1.dodaj(w2);
            w1.dodaj(w3);
            w2.dodaj(w4);
            w2.dodaj(w5);
            w2.dodaj(w6);
            w2.dodaj(w7);
            w5.dodaj(w7);
            A(w1);
        }
    }
}