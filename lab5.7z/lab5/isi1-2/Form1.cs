using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace isi1_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var w1 = new W�ze�(5);
            var w2 = new W�ze�(3);
            var w3 = new W�ze�(1);
            var w4 = new W�ze�(2);
            var w5 = new W�ze�(6);
            var w6 = new W�ze�(4);
            w1.dzieci.Add(w2);
            w1.dzieci.Add(w3);
            w1.dzieci.Add(w4);
            w2.dzieci.Add(w5);
            w2.dzieci.Add(w6);

            var p1 = new W�ze�2(1);
            var p2 = new W�ze�2(2);
            var p3 = new W�ze�2(3);
            var p4 = new W�ze�2(4);
            var p5 = new W�ze�2(5);
            var p6 = new W�ze�2(6);

            p1.Add(p2);
            p1.Add(p3);
            p2.Add(p4);
            p2.Add(p5);
            p3.Add(p6);
            p4.Add(p6);

            DetectCycles(p1);
        }

        void DetectCycles(W�ze�2 root)
        {
            HashSet<W�ze�2> visited = new HashSet<W�ze�2>();
            foreach (var node in root.s�siad)
            {
                if (!visited.Contains(node))
                {
                    if (HasCycle(node, visited, root))
                    {
                        MessageBox.Show("Graf zawiera cykl!");
                        return;
                    }
                }
            }
            MessageBox.Show("Graf nie zawiera cyklu.");
        }

        bool HasCycle(W�ze�2 current, HashSet<W�ze�2> visited, W�ze�2 parent)
        {
            visited.Add(current);
            foreach (var neighbor in current.s�siad)
            {
                if (!visited.Contains(neighbor))
                {
                    if (HasCycle(neighbor, visited, current))
                        return true;
                }
                else if (neighbor != parent)
                {
                    return true;
                }
            }
            return false;
        }
    

    void A(W�ze� w)
            {
                MessageBox.Show(w.warto��.ToString());
                for (int i = 0; i < w.dzieci.Count; i++)
                {
                    A(w.dzieci[i]);
                }
            }
            void B(W�ze�2 ww)
            {
                MessageBox.Show(ww.warto.ToString());
                for (int j = 0; j < ww.s�siad.Count; j++)
                {
                    B(ww.s�siad[j]);
                }
            }
        
    
        public class W�ze�
        {
            public int warto��;
            public List<W�ze�> dzieci = new List<W�ze�>();
            public W�ze�(int liczba)
            {
                this.warto�� = liczba;
            }
        }
        public class W�ze�2
        {
            public int warto;
            public List<W�ze�2> s�siad = new List<W�ze�2>();
            public W�ze�2(int liczba)
            {
                this.warto = liczba;
            }
            public void Add(W�ze�2 s)
            {
                if (s == this)
                {
                    return;
                }
                if (!this.s�siad.Contains(s))
                {
                    this.s�siad.Add(s);
                    s.s�siad.Add(this);
                }
                if (!s.s�siad.Contains(this))
                {
                    s.s�siad.Add(this);
                }
            }
        }
    }
}
